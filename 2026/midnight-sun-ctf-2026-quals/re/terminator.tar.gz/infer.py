#!/usr/bin/env -S uv run --script
# /// script
# requires-python = ">=3.12"
# dependencies = ["jax", "flax", "optax", "einops", "numpy", "tqdm"]
# ///
"""
    ./infer.py                # interactive
    ./infer.py PROMPT         # one-shot

`uv` installs deps on first run — https://docs.astral.sh/uv
"""

import argparse
import json
import pickle
import sys
from dataclasses import asdict, dataclass
from pathlib import Path

import jax
import jax.numpy as jnp
import numpy as np
import optax
from einops import einsum, rearrange
from flax import nnx
from tqdm import tqdm

EOP, EOS, VOCAB = 256, 257, 258
DTYPE = jnp.bfloat16


@dataclass
class Config:
    dim:    int = 512
    heads:  int = 8
    layers: int = 4


def rope(x, pos, *, wavelength=10_000):

    frac     = 2 * jnp.arange(x.shape[-1] // 2) / x.shape[-1]
    inp      = pos[:, None] / wavelength ** frac
    sin, cos = jnp.sin(inp), jnp.cos(inp)
    a, b     = jnp.split(x, 2, axis=-1)

    return jnp.concatenate([a * cos - b * sin, b * cos + a * sin], axis=-1).astype(x.dtype)


class Attention(nnx.Module):

    def __init__(self, dim, heads, *, rngs, dtype):
        assert dim % heads == 0, f"dim {dim} not divisible by heads {heads}"
        self.heads    = heads
        self.head_dim = dim // heads
        self.qkv      = nnx.Linear(dim, dim * 3, rngs=rngs, param_dtype=dtype)

    def __call__(self, x):

        qkv     = rearrange(self.qkv(x), "s (three h d) -> three h s d", three=3, h=self.heads)
        q, k, v = qkv[0], qkv[1], qkv[2]

        pos = jnp.arange(x.shape[0])
        q   = jax.vmap(rope, in_axes=(0, None))(q, pos)
        k   = jax.vmap(rope, in_axes=(0, None))(k, pos)

        scores = einsum(q, k, "h q d, h k d -> h q k") * self.head_dim ** -0.5
        mask   = jnp.tril(jnp.ones((x.shape[0], x.shape[0])))
        scores = jnp.where(mask, scores, jnp.finfo(scores.dtype).min)
        w      = jax.nn.softmax(scores, axis=-1)

        y = einsum(w, v, "h q k, h k d -> h q d")
        return rearrange(y, "h s d -> s (h d)")


class Block(nnx.Module):

    def __init__(self, dim, heads, *, rngs, dtype):
        self.norm1 = nnx.LayerNorm(dim, rngs=rngs, param_dtype=dtype)
        self.attn  = Attention(dim, heads, rngs=rngs, dtype=dtype)
        self.norm2 = nnx.LayerNorm(dim, rngs=rngs, param_dtype=dtype)
        self.ff1   = nnx.Linear(dim, dim * 4, rngs=rngs, param_dtype=dtype)
        self.ff2   = nnx.Linear(dim * 4, dim, rngs=rngs, param_dtype=dtype)

    def __call__(self, x):
        x = x + self.attn(self.norm1(x))
        x = x + self.ff2(nnx.gelu(self.ff1(self.norm2(x))))
        return x


class Model(nnx.Module):

    def __init__(self, cfg: Config, *, rngs, dtype=DTYPE):
        self.embed  = nnx.Embed    (VOCAB,   cfg.dim, rngs=rngs, param_dtype=dtype)
        self.blocks = nnx.data([Block(cfg.dim, cfg.heads, rngs=rngs, dtype=dtype) for _ in range(cfg.layers)])
        self.norm   = nnx.LayerNorm(cfg.dim,          rngs=rngs, param_dtype=dtype)
        self.head   = nnx.Linear   (cfg.dim, VOCAB,   rngs=rngs, param_dtype=dtype)

    def __call__(self, tokens):
        x = self.embed(tokens)
        for b in self.blocks:
            x = b(x)
        return self.head(self.norm(x))


def infer(
    prompt:  str  = "",
    ckpt:    Path = Path("./ckpt"),
    max_len: int  = 4096,
):

    if not prompt:
        prompt = input("prompt: ").strip()
        if not prompt:
            sys.exit("empty prompt")

    cfg    = Config(**json.load(open(ckpt / "config.json")))
    gd, _  = nnx.split(Model(cfg, rngs=nnx.Rngs(0)))
    params = pickle.load(open(ckpt / "params.pkl", "rb"))

    prefix            = np.array(list(prompt.encode()) + [EOP], dtype=np.int32)
    buf               = np.zeros(max_len, dtype=np.int32)
    buf[:len(prefix)] = prefix

    @jax.jit
    def predict(params, seq, i):
        return nnx.merge(gd, params)(seq)[i]

    i = len(prefix)
    while i < max_len:
        nxt = int(jnp.argmax(predict(params, jnp.array(buf), jnp.array(i - 1))))
        if nxt == EOS:
            break
        buf[i] = nxt
        i += 1

    sys.stdout.write(bytes(buf[len(prefix):i]).hex())
    sys.stdout.write("\n")


def main():
    argv = sys.argv[1:]

    infer(argv[0] if argv else "")


if __name__ == "__main__":
    main()
